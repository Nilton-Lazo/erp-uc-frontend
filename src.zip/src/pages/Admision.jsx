// src/pages/Admision.jsx
import React from 'react'

export default function Admision() {
  return (
    <div className="flex items-center justify-center h-full bg-white">
      <h1 className="text-3xl font-bold text-gray-800">Bienvenido a Admisión</h1>
    </div>
  )
}